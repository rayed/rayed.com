#! /usr/bin/perl -w
# client1.pl - a simple client
#----------------

use strict;
use Socket;

local $SIG{ALRM} = sub { die "";};
alarm 2; 

# initialize host and port
my $host = shift || 'localhost';
my $port = shift || 11211;

my $proto = getprotobyname('tcp');

# get the port address
my $iaddr = inet_aton($host);
my $paddr = sockaddr_in($port, $iaddr);
# create the socket, connect to the port
socket(SOCKET, PF_INET, SOCK_STREAM, $proto) or die "socket: $!";
connect(SOCKET, $paddr) or die "connect: $!";

select(SOCKET); $| = 1; select(STDOUT);
print SOCKET "stats\r\n";


my $line;
while ($line = <SOCKET>)
{
last if ($line =~ /END/); 
$line =~ s/.* (\d+)/$1/;
print $line;
}
close SOCKET or die "close: $!"; 
