#!/usr/bin/perl

use LWP::UserAgent;
use FileHandle;

die("Usage: $0 <URL> \n")   unless @ARGV == 1;

# Set the URL to the server status page
($URL, $DELTA) = @ARGV;

unless ($URL =~ /^http:/i) {
    die("Must provide a full url you sent: $URL\n");
    }

# How long to wait for a reply
$timeout = 30;


## BEGIN ##

# Do some basic setup of the UserAgent package
$ua = new LWP::UserAgent;
$ua->agent("apache-stats/1.1" . $ua->agent);
$ua->timeout($timeout);


# Setup the request ?auto is appended to the URL to get the result in a
# more machine readable format

$request = new HTTP::Request('GET', $URL . "?auto");
$response = $ua->request($request);

#
# Collect the results into a hash table.
#
%ans = split/:\s*|\n/, $response->content;
warn "unexpected (non-server-status) data seen" unless keys %ans == 4;


print <<"==END==";
$ans{"Total Accesses"}
$ans{"Total kBytes"}
$ans{Uptime}
$ans{BusyServers}
==END==

